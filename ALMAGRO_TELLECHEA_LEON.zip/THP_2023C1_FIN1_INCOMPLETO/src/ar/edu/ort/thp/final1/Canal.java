package ar.edu.ort.thp.final1;

import java.util.ArrayList;

public class Canal {
	private static final int DURACION_TOTAL = 24;
	private TipoContenido tipo;
	private ArrayList<Programa> grilla;
	
	
	public Canal(TipoContenido tipo) {
		this.setTipo(tipo);
		this.grilla = new ArrayList<Programa>();
	}
	
	private void setTipo(TipoContenido tipo) {
		this.tipo = tipo;
	}
	
	public TipoContenido getTipo() {
		return this.tipo;
	}

	public ArrayList<Programa> getGrilla() {
		return grilla;
	}
	
	public boolean isGrillaCompleta() {
		return (grilla.size() > 0 && grilla.size() * grilla.get(0).getDuracion() >= Canal.DURACION_TOTAL);
	}
	
	public boolean agregarPrograma(Programa programa) {
		boolean resultado = false;
		if (!this.isGrillaCompleta()) {
			resultado = this.grilla.add(programa);
		}
		return resultado;
	}

	public boolean esMismoTipo(TipoContenido tipo) {
		return this.tipo.equals(tipo);
	}

    public void mostrarCanal() {
        System.out.println("*** Grilla - " + tipo + " ***");

        if (grilla.size() == 0) {
            System.out.println("Grilla vacía");
        } else {
            for (Programa programa : grilla) {
                programa.mostrar();
            }
        }

    }
}
