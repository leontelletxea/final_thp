package ar.edu.ort.thp.final1;

public enum TipoContenido {
	PELICULA,
	NOVELA,
	COCINA
}
