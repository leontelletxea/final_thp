package ar.edu.ort.thp.final1;

public class Test {
	private static Productora ortProduce = new Productora();

	public static void main(String[] args) {
		agregarPrograma(TipoContenido.NOVELA, "Only Murders in The Building");
		agregarPrograma(TipoContenido.NOVELA, "Succession");
		agregarPrograma(TipoContenido.COCINA, "Cocina con Giada");
		agregarPrograma(TipoContenido.COCINA, "Jamie Oliver");
		agregarPrograma(TipoContenido.PELICULA, "Spiderman");
		agregarPrograma(TipoContenido.COCINA, "Paulina Cocina");
		agregarPrograma(TipoContenido.COCINA, "Maestros del Pan");
		agregarPrograma(TipoContenido.NOVELA, "Doctor Who");
		agregarPrograma(TipoContenido.NOVELA, "Grey's Anatomy");
		agregarPrograma(TipoContenido.COCINA, "Rescata mi restaurante");
		agregarPrograma(TipoContenido.COCINA, "Cocina a la parrilla");
		agregarPrograma(TipoContenido.PELICULA, "Saving Private Ryan");

		generarProgramacion();
		
		mostrarProgramacion();
	}
	
	private static void agregarPrograma(TipoContenido tipo, String descripcion) {
		System.out.println("Agregando programa: " + descripcion + "...");
		if (!ortProduce.agregarPrograma(new Programa(tipo, descripcion))) {
			System.err.println("¡Error al agregarlo!");
		}
	}
	
	private static void generarProgramacion() {
		System.out.println();
		System.out.println("Generando la programacion de todos los canales...");
		ortProduce.generarProgramacion();
		System.out.println("¡Programacion finalizada!");
	}

	private static void mostrarProgramacion() {
		System.out.println();
		ortProduce.mostrarProgramacion();
	}
}
