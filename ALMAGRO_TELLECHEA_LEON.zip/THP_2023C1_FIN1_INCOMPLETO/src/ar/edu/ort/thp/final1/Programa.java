package ar.edu.ort.thp.final1;

public class Programa {
	private TipoContenido tipo;
	private String nombre;
	private int duracion;
	
	public Programa(TipoContenido tipo, String nombre) {
		setTipo(tipo);
		setNombre(nombre);
		this.calcularDuracion();
	}

	private void calcularDuracion() {
		final int DURACION_PELICULA = 3;
		final int DURACION_NOVELA = 2;
		final int DURACION_COCINA = 1;
		
		switch (tipo) {
		case COCINA:
			setDuracion(DURACION_COCINA);
			break;
		case NOVELA:
			setDuracion(DURACION_NOVELA);
			break;
		case PELICULA:
			setDuracion(DURACION_PELICULA);
			break;
		}
	}

	private void setTipo(TipoContenido tipo) {
		this.tipo = tipo;
	}
	
	public TipoContenido getTipo() {
		return this.tipo;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}

	private void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	
	public int getDuracion() {
		return this.duracion;
	}

	public boolean mismoNombre(String nombre) {
		return this.nombre.trim().equalsIgnoreCase(nombre.trim());
	}

	public void mostrar() {
		System.out.println("Programa: " + this.nombre);
	}
}
