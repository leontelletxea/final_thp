package ar.edu.ort.thp.final1;

import java.util.ArrayList;

public class Productora {
	private ArrayList<Programa> programas;
	private ArrayList<Canal> canales;

	public Productora() {
		this.programas = new ArrayList<Programa>();
		this.canales = new ArrayList<Canal>();
		this.crearCanales();
	}

	private void crearCanales() {
		this.canales.add(new Canal(TipoContenido.PELICULA));
		this.canales.add(new Canal(TipoContenido.NOVELA));
		this.canales.add(new Canal(TipoContenido.COCINA));
	}

	private Programa buscarPrograma(String nombre) {
		Programa progADevolver = null;
		Programa progActual;
		int pos = 0;

		while (pos < this.programas.size() && progADevolver == null) {
			progActual = this.programas.get(pos);

			if (progActual.mismoNombre(nombre)) {
				progADevolver = progActual;
			} else {
				pos++;
			}
		}

		return progADevolver;
	}

	public boolean agregarPrograma(Programa programa) {
		boolean pudoAgregar = false;

		if (buscarPrograma(programa.getNombre()) == null) {
			pudoAgregar = this.programas.add(programa);
		}
		return pudoAgregar;
	}

	//TODO: completar este metodo (y todos los submetodos que considere necesarios)
	public void generarProgramacion() {
        for(Programa programa : this.programas){
            int i = 0;
            while (i < canales.size() && !canales.get(i).esMismoTipo(programa.getTipo())) {
                i++;
            }

            if(i < canales.size()){
                Canal canal = canales.get(i);
                canal.agregarPrograma(programa);
            }
        }

		completarProgramacion();
    }

	public void completarProgramacion(){
		for(Canal canal : this.canales){
            int i = 0;
			
			if(canal.getGrilla().size() > 0){
				while(!canal.isGrillaCompleta()){
					canal.agregarPrograma(canal.getGrilla().get(i));
					i++;
				}
			}
        }
	}
	
	//TODO: completar este metodo (y todos los submetodos que considere necesarios)
	public void mostrarProgramacion() {

		System.out.println("**** Productora - Canales ****");

		for(Canal canal : this.canales){
			canal.mostrarCanal();
		}
	}
}
