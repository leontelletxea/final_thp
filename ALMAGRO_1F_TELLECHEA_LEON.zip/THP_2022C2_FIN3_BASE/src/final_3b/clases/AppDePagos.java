package final_3b.clases;

import java.util.ArrayList;

//import examen.clases.Persona;

public class AppDePagos {

	private Usuario usuario;
	private ArrayList<Servicio> serviciosAPagar;
	private ArrayList<Servicio> serviciosAbonados;
	
	public AppDePagos() {
		this.serviciosAPagar = new ArrayList<Servicio>();
		this.serviciosAbonados = new ArrayList<Servicio>();
	}

	/**
	 * Agrega saldo de caja (disponible para pagar servicios). Debe ser mayor que
	 * cero.
	 * 
	 * @param monto - El monto a agregar
	 * @return El resultado de la operacion
	 */
	public Resultado agregarSaldo(double monto) {
		Resultado resultado = Resultado.OPERACION_OK;
		
		if(this.usuario != null) {
			if(monto < 0) {
				resultado = Resultado.ERROR_EN_MONTO;
			}else {
				this.usuario.setSaldo(monto);
			}
		}
		
		return resultado;
	}

	/**
	 * Agrega un servicio a pagar. Debe chequearse que el mismo no exista en la
	 * lista de impagos. En caso de que exista debe devolver SERVICIO DUPLICADO
	 * (sino OK).
	 * 
	 * @param nombre      - El nombre del servicio
	 * @param comprobante - El nro de comprobante
	 * @param importe     - El importe a pagar
	 * @return El resultado de la operacion
	 */
	public Resultado agregarServicioAPagar(String nombre, int comprobante, double importe) {
		// TODO - Reemplazar el null por lo que corresponda y completar
		Resultado resultado = Resultado.OPERACION_OK;
		Servicio servicio = new Servicio(nombre, comprobante, importe);
		
		if(existeServicio(servicio, nombre) == Resultado.OPERACION_OK) {
			this.serviciosAPagar.add(servicio);
		}else {
			resultado = Resultado.SERVICIO_DUPLICADO;
		}
		
		return resultado;
	}
	
	private Resultado existeServicio(Servicio servicio, String nombreServicio) {
		Resultado resultado = Resultado.OPERACION_OK;
		int i = 0;
		
		while(i < this.serviciosAPagar.size() && resultado == Resultado.OPERACION_OK) {
			
			resultado = servicio.mismoServicio(serviciosAPagar.get(i).getNombre());
			i++;
		}
		
		return resultado;
	}
	
	// TODO - Usar donde corresponda
	private void mostrarErrorSinUsuario() {
		System.out.println("No hay usuario asignado");
	}

	/**
	 * Mostrar los servicios pagados por el usuario. Debe mostrar, al final, el
	 * monto total de lo abonado. Cuando la aplicacion no tiene usuario asignado
	 * muestra el mensaje relacionado a esto.
	 */
	public void mostrarServiciosPagados() {
		
	    for(Servicio servicio : this.serviciosAbonados) {
	    	System.out.println("Servicio pagado: " + servicio.getNombre());
	    	System.out.println("Total pagado: " + servicio.getImporte());
	      }
	}

	/**
	 * Pagar un servicio, chequeando que tanto el usuario como el servicio existan y
	 * que alcance el saldo. En caso de fallar debe devolver el codigo de error
	 * correspondiente; en caso de realizar correctamente el pago ademas del OK el
	 * servicio debe quedar entre los pagados.
	 * 
	 * @param nombreServicio - El nombre del servicio a pagar
	 * @return El resultado de la operacion.
	 */
	public Resultado pagarServicio(String nombreServicio) {
		// TODO - Reemplazar el null por lo que corresponda y completar
		Resultado resultado = Resultado.SERVICIO_SIN_PENDIENTES;
		Servicio servicio = null;
		int i = 0;
		
		if(this.usuario != null) {
			while(i < this.serviciosAPagar.size() && resultado == Resultado.SERVICIO_SIN_PENDIENTES) {
				servicio = this.serviciosAPagar.get(i);
				
					if(servicio.mismoServicio(nombreServicio) == Resultado.SERVICIO_DUPLICADO) {
						
						if(servicio.getImporte() > 0) {
							
							if(this.usuario.getSaldo() >= servicio.getImporte()) {
								this.usuario.setSaldo(this.usuario.getSaldo() - servicio.getImporte());
								this.serviciosAPagar.remove(i);
								this.serviciosAbonados.add(servicio);
								resultado = Resultado.OPERACION_OK;
							}else {
								resultado = Resultado.SALDO_INSUFICIENTE;
							}
						}
				}
				i++;
			}
		}else {
			resultado = Resultado.USUARIO_INEXISTENTE;
		}
		
		return resultado;
	}
	


	/**
	 * Asigna el usuario que usa la aplicacion: debe crearlo siempre y cuando no
	 * haya otro usuario registrado previamente. En caso de que la aplicacion ya
	 * tenga un usuario registrado el debe devolver el mensaje de error
	 * correspondiente.
	 * 
	 * @param cuil - CUIL/CUIT del usuario
	 * @param nombre - Nombre del usuario
	 * @return El resultado de la operacion.
	 */
	public Resultado registrarUsuario(String cuil, String nombre) {
		Resultado resultado = null;
		
		if(this.usuario == null) {
			this.usuario = new Usuario(cuil, nombre);
			resultado = Resultado.OPERACION_OK;
		}else {
			resultado = Resultado.USUARIO_YA_EXISTENTE;
		}
		
		return resultado;
	}

	/**
	 * Asigna el usuario que usa la aplicacion: debe crearlo siempre y cuando no
	 * haya otro usuario registrado previamente. En caso de que la aplicacion ya
	 * tenga un usuario registrado el debe devolver el mensaje de error
	 * correspondiente.
	 * 
	 * @param cuil - CUIL/CUIT del usuario
	 * @param nombre - Nombre del usuario
	 * @param saldoInicial - Dinero depositado inicialmente
	 * @return El resultado de la operacion.
	 */
	public Resultado registrarUsuario(String cuil, String nombre, double saldoInicial) {
		Resultado resultado = null;
		
		if(this.usuario == null) {
			if(saldoInicial < 0) {
				saldoInicial = 0;
			}
			this.usuario = new Usuario(cuil, nombre, saldoInicial);
			resultado = Resultado.OPERACION_OK;
		}else {
			resultado = Resultado.USUARIO_YA_EXISTENTE;
		}
		
		return resultado;
	}

}