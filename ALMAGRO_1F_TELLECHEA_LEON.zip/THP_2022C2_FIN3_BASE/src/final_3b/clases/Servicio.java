package final_3b.clases;

public class Servicio {

	private String nombre;
	private int comprobante;
	private double importe;
	
	public Servicio(String nombre, int comprobante, double importe) {
		this.nombre = nombre;
		this.comprobante = comprobante;
		this.importe = importe;
	}

	public Resultado mismoServicio(Servicio servicio) {
		Resultado resultado = Resultado.OPERACION_OK;
		
		if(servicio.equals(this)) {
			resultado = Resultado.SERVICIO_DUPLICADO;
		}
		
		return resultado;
	}
	
	public Resultado mismoServicio(String nombreServicio) {
		Resultado resultado = Resultado.OPERACION_OK;
		
		if(nombreServicio.equals(this.nombre)) {
			resultado = Resultado.SERVICIO_DUPLICADO;
		}
		
		return resultado;
	}
	
	@Override
	public String toString() {
		return "Servicio [nombre=" + nombre + ", comprobante=" + comprobante + ", importe=" + importe + "]";
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getComprobante() {
		return comprobante;
	}

	public void setComprobante(int comprobante) {
		this.comprobante = comprobante;
	}

	public double getImporte() {
		return importe;
	}

	public void setImporte(double importe) {
		this.importe = importe;
	}

}