package final_3b.clases;

public class Usuario {

	private String cuit;
	private String nombre;
	private double saldo;
	
	public Usuario(String cuit, String nombre, double saldo) {
		this.cuit = cuit;
		this.nombre = nombre;
		this.saldo = saldo;
	}
	
	public Usuario(String cuit, String nombre) {
		this.cuit = cuit;
		this.nombre = nombre;
		this.saldo = 0;
	}
	
	@Override
	public String toString() {
		return "Usuario [cuit=" + cuit + ", nombre=" + nombre + ", saldo=" + saldo + "]";
	}
	
	public String getCuit() {
		return cuit;
	}

	public void setCuit(String cuit) {
		this.cuit = cuit;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
}
